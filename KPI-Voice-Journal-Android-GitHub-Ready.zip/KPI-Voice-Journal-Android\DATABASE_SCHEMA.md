# Database Schema

## activities

| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | Auto-increment |
| date | TEXT | ISO `YYYY-MM-DD` |
| project_name | TEXT | |
| purpose | TEXT | |
| remote_onsite | TEXT | |
| si_nd | TEXT | |
| contact_person | TEXT | |
| customer_name | TEXT | |
| country | TEXT | |
| description | TEXT | Raw transcript/manual description |
| enhanced_description | TEXT | Offline professional wording |
| product | TEXT | |
| channel | TEXT | |
| start_time / stop_time | TEXT | `HH:mm` |
| duration_minutes | INTEGER | |
| status | TEXT | |
| activity_category | TEXT | Technical Support / Project Delivery Support / Training |
| fault_description | TEXT | |
| resolution | TEXT | |
| notes | TEXT | |
| created_at / updated_at | INTEGER | Unix milliseconds |

## photos

| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | |
| record_id | INTEGER FK | Cascade delete |
| local_path | TEXT | App-private embedded file path |
| file_name | TEXT | Exported to Excel |
| caption | TEXT | Exported to Excel |
| category | TEXT | Editable photo category |
