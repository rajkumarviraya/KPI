package com.rajkumar.kpijournal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rajkumar.kpijournal.data.*
import java.io.File

private enum class Screen { HOME, ADD, RECORDS, EXPORT, SETTINGS }
private val Navy = Color(0xFF173B57)
private val Teal = Color(0xFF2A9D8F)

@Composable
fun JournalApp(
    viewModel: JournalViewModel,
    onToggleVoice: () -> Unit,
    onPickPhotos: () -> Unit,
    onTakePhoto: () -> Unit,
    onPickTemplate: () -> Unit,
    onPickBackup: () -> Unit,
    onShare: (File) -> Unit,
) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel.message) {
        if (viewModel.message.isNotBlank()) snackbar.showSnackbar(viewModel.message)
    }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Surface(color = Navy, contentColor = Color.White) {
                Row(Modifier.fillMaxWidth().padding(18.dp, 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("KPI Voice Journal", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("Offline • Excel-template aware", style = MaterialTheme.typography.labelMedium)
                    }
                    Icon(Icons.Default.CloudOff, contentDescription = "Offline")
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavItem(Screen.HOME, screen, Icons.Default.Home, "Home") { screen = it }
                NavItem(Screen.ADD, screen, Icons.Default.Mic, "Record") { viewModel.newRecord(); screen = it }
                NavItem(Screen.RECORDS, screen, Icons.Default.List, "Records") { viewModel.refresh(); screen = it }
                NavItem(Screen.EXPORT, screen, Icons.Default.FileDownload, "Excel") { screen = it }
                NavItem(Screen.SETTINGS, screen, Icons.Default.Settings, "Settings") { screen = it }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.HOME -> HomeScreen(viewModel, onVoice = { viewModel.newRecord(); screen = Screen.ADD; onToggleVoice() }, onManual = { viewModel.newRecord(); screen = Screen.ADD })
                Screen.ADD -> RecordEditor(viewModel, onToggleVoice, onPickPhotos, onTakePhoto) { screen = Screen.RECORDS }
                Screen.RECORDS -> RecordsScreen(viewModel, onEdit = { viewModel.edit(it); screen = Screen.ADD }, onDuplicate = { viewModel.duplicate(it); screen = Screen.ADD })
                Screen.EXPORT -> ExportScreen(viewModel, onPickTemplate, onShare)
                Screen.SETTINGS -> SettingsScreen(viewModel, onPickBackup, onShare)
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(target: Screen, current: Screen, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, go: (Screen) -> Unit) {
    NavigationBarItem(selected = target == current, onClick = { go(target) }, icon = { Icon(icon, label) }, label = { Text(label) })
}

@Composable
private fun HomeScreen(vm: JournalViewModel, onVoice: () -> Unit, onManual: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Record today’s work in seconds", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Speak naturally, review the fields, attach photos, and save offline.", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF4F2))) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    FilledIconButton(onClick = onVoice, modifier = Modifier.size(84.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Teal)) {
                        Icon(Icons.Default.Mic, "Start voice", Modifier.size(42.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Tap and speak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Offline recognition is preferred when installed on the phone.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = onManual) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Manual entry") }
                }
            }
        }
        item {
            val s = vm.stats
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCard("Total", s.total.toString(), Modifier.weight(1f)); KpiCard("Today", s.today.toString(), Modifier.weight(1f)); KpiCard("This month", s.month.toString(), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCard("Support", s.support.toString(), Modifier.weight(1f)); KpiCard("Projects", s.project.toString(), Modifier.weight(1f)); KpiCard("Training", s.training.toString(), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCard("Countries", s.countries.toString(), Modifier.weight(1f)); KpiCard("Products", s.products.toString(), Modifier.weight(1f)); KpiCard("Hours", "%.1f".format(s.totalMinutes / 60.0), Modifier.weight(1f))
                }
            }
        }
        item {
            Text("Recent activities", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            vm.records.take(5).forEach { MiniRecord(it) }
        }
    }
}

@Composable
private fun KpiCard(label: String, value: String, modifier: Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(value, style = MaterialTheme.typography.headlineSmall, color = Navy, fontWeight = FontWeight.Bold); Text(label, style = MaterialTheme.typography.labelSmall) } }
}

@Composable
private fun MiniRecord(record: JournalRecord) {
    ListItem(
        headlineContent = { Text(record.activity.enhancedDescription.ifBlank { record.activity.description }, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(listOf(record.activity.date, record.activity.country, record.activity.product).filter(String::isNotBlank).joinToString(" • ")) },
        trailingContent = { Text(record.activity.status, style = MaterialTheme.typography.labelSmall, color = Teal) },
    )
}

@Composable
private fun RecordEditor(vm: JournalViewModel, onVoice: () -> Unit, onPickPhotos: () -> Unit, onTakePhoto: () -> Unit, onSaved: () -> Unit) {
    val a = vm.draft
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Voice or manual record", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = vm.transcript, onValueChange = { vm.updateTranscript(it) }, label = { Text("Voice transcript / description") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onVoice, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text("Start / Stop") }
            OutlinedButton(onClick = vm::parseTranscript, modifier = Modifier.weight(1f)) { Text("Extract fields") }
        }
        ChoiceField("Activity Category", a.activityCategory, vm.config.categories) { vm.updateDraft(a.copy(activityCategory = it, purpose = it)) }
        EditField("Date (YYYY-MM-DD)", a.date) { vm.updateDraft(a.copy(date = it)) }
        EditField("Project Name", a.projectName) { vm.updateDraft(a.copy(projectName = it)) }
        EditField("Customer Name", a.customerName) { vm.updateDraft(a.copy(customerName = it)) }
        ChoiceField("Country", a.country, vm.config.countries) { vm.updateDraft(a.copy(country = it)) }
        ChoiceField("Product", a.product, vm.config.products) { vm.updateDraft(a.copy(product = it)) }
        ChoiceField("Remote / Onsite", a.remoteOnsite, vm.config.modes) { vm.updateDraft(a.copy(remoteOnsite = it)) }
        ChoiceField("SI / ND", a.siNd, vm.config.siNd) { vm.updateDraft(a.copy(siNd = it)) }
        EditField("Contact Person", a.contactPerson) { vm.updateDraft(a.copy(contactPerson = it)) }
        ChoiceField("Channel", a.channel, vm.config.channels) { vm.updateDraft(a.copy(channel = it)) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EditField("Start (HH:mm)", a.startTime, Modifier.weight(1f)) { vm.updateDraft(a.copy(startTime = it)) }
            EditField("Stop (HH:mm)", a.stopTime, Modifier.weight(1f)) { vm.updateDraft(a.copy(stopTime = it)) }
        }
        ChoiceField("Status", a.status, vm.config.statuses) { vm.updateDraft(a.copy(status = it)) }
        EditField("Issue / Fault", a.faultDescription, minLines = 2) { vm.updateDraft(a.copy(faultDescription = it)) }
        EditField("Resolution / Action Taken", a.resolution, minLines = 2) { vm.updateDraft(a.copy(resolution = it)) }
        EditField("Enhanced Description", a.enhancedDescription, minLines = 3) { vm.updateDraft(a.copy(enhancedDescription = it)) }
        EditField("Notes", a.notes, minLines = 2) { vm.updateDraft(a.copy(notes = it)) }
        Text("Photos (${vm.pendingPhotos.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onTakePhoto) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(5.dp)); Text("Camera") }
            OutlinedButton(onClick = onPickPhotos) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(5.dp)); Text("Gallery") }
        }
        vm.pendingPhotos.forEachIndexed { index, photo ->
            Card {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(photo.file.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { vm.removePendingPhoto(index) }) { Icon(Icons.Default.Delete, "Remove photo") }
                    }
                    EditField("Photo caption", photo.caption) { vm.updatePendingPhoto(index, caption = it) }
                    ChoiceField("Photo category", photo.category, vm.config.photoCategories) { vm.updatePendingPhoto(index, category = it) }
                }
            }
        }
        Button(onClick = { vm.saveDraft(); onSaved() }, modifier = Modifier.fillMaxWidth().height(54.dp), enabled = a.activityCategory.isNotBlank()) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save offline")
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun EditField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), minLines: Int = 1, update: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = update, label = { Text(label) }, minLines = minLines, modifier = modifier)
}

@Composable
private fun ChoiceField(label: String, value: String, choices: List<String>, update: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(value.ifBlank { "Select" }, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                choices.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { update(it); open = false }) }
            }
        }
    }
}

@Composable
private fun RecordsScreen(vm: JournalViewModel, onEdit: (JournalRecord) -> Unit, onDuplicate: (JournalRecord) -> Unit) {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<JournalRecord?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        fun apply() = vm.refresh(RecordFilter(query = search, category = category, status = status))
        OutlinedTextField(search, { search = it; apply() }, label = { Text("Search customer, project or description") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { ChoiceField("Category", category, listOf("") + vm.config.categories) { category = it; apply() } }
            Box(Modifier.weight(1f)) { ChoiceField("Status", status, listOf("") + vm.config.statuses) { status = it; apply() } }
        }
        Text("${vm.records.size} records", Modifier.padding(4.dp), style = MaterialTheme.typography.labelMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.records, key = { it.activity.id }) { record ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(record.activity.enhancedDescription.ifBlank { record.activity.description }, maxLines = 3, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(listOf(record.activity.date, record.activity.activityCategory, record.activity.country, record.activity.product).filter(String::isNotBlank).joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onDuplicate(record) }) { Text("Duplicate") }
                            TextButton(onClick = { onEdit(record) }) { Text("Edit") }
                            TextButton(onClick = { confirmDelete = record }) { Text("Delete", color = Color(0xFFB43A30)) }
                        }
                    }
                }
            }
        }
    }
    confirmDelete?.let { record ->
        AlertDialog(onDismissRequest = { confirmDelete = null }, title = { Text("Delete record?") }, text = { Text("The record and local photos will be permanently removed.") },
            confirmButton = { TextButton(onClick = { vm.delete(record.activity.id); confirmDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } })
    }
}

@Composable
private fun ExportScreen(vm: JournalViewModel, onPickTemplate: () -> Unit, onShare: (File) -> Unit) {
    var period by remember { mutableStateOf("All Records") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel export", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF1F5))) {
            Column(Modifier.padding(16.dp)) {
                Text("Active format", style = MaterialTheme.typography.labelMedium)
                Text(vm.template.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${vm.template.sheets.size} sheets • ${vm.template.sourceFileName}", style = MaterialTheme.typography.bodySmall)
            }
        }
        ChoiceField("Export period", period, listOf("All Records", "This Month", "This Quarter", "H1", "H2", "This Year")) { period = it }
        Button(onClick = { vm.export(vm.periodFilter(period), onReady = onShare) }, modifier = Modifier.fillMaxWidth().height(56.dp), enabled = !vm.busy) {
            Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text(if (vm.busy) "Working…" else "Export all records to Excel")
        }
        OutlinedButton(onClick = onPickTemplate, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Import changed Excel format") }
        Text("The app scans the imported workbook for sheet names, header rows and column names. Your stored records stay unchanged; only the output mapping changes.", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = vm::useSampleTemplate) { Text("Use H1 2026 Activities sample profile") }
        HorizontalDivider()
        Text("Detected mapping", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        vm.template.sheets.forEach { sheet ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text(sheet.sheetName, fontWeight = FontWeight.Bold)
                    Text("${sheet.category.ifBlank { "All records" }} • header row ${sheet.headerRow} • ${sheet.headers.size} columns", style = MaterialTheme.typography.bodySmall)
                    Text(sheet.headers.joinToString(" • "), style = MaterialTheme.typography.labelSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: JournalViewModel, onPickBackup: () -> Unit, onShare: (File) -> Unit) {
    var config by remember(vm.config) { mutableStateOf(vm.config) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        ConfigList("Products", config.products) { config = config.copy(products = parseList(it)) }
        ConfigList("Countries", config.countries) { config = config.copy(countries = parseList(it)) }
        ConfigList("Statuses", config.statuses) { config = config.copy(statuses = parseList(it)) }
        ConfigList("Activity categories", config.categories) { config = config.copy(categories = parseList(it)) }
        ConfigList("Channels", config.channels) { config = config.copy(channels = parseList(it)) }
        Button(onClick = { vm.saveConfig(config) }, modifier = Modifier.fillMaxWidth()) { Text("Save dropdown lists") }
        HorizontalDivider()
        Text("Excel header mapping", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        vm.template.sheets.forEach { sheet ->
            var category by remember(sheet.sheetName, sheet.category) { mutableStateOf(sheet.category) }
            var headers by remember(sheet.sheetName, sheet.headers) { mutableStateOf(sheet.headers.joinToString("\n")) }
            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(sheet.sheetName, fontWeight = FontWeight.Bold)
                    ChoiceField("Records sent to this sheet", category, listOf("", "Technical Support", "Project Delivery Support", "Training")) { category = it }
                    OutlinedTextField(headers, { headers = it }, label = { Text("One Excel header per line") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { vm.updateTemplateSheet(sheet.sheetName, category, headers) }) { Text("Save sheet mapping") }
                }
            }
        }
        HorizontalDivider()
        Text("Backup and restore", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Button(onClick = { vm.backup(onShare) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("Create and share database backup") }
        OutlinedButton(onClick = onPickBackup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("Restore database backup") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ConfigList(label: String, values: List<String>, update: (String) -> Unit) {
    var text by remember(values) { mutableStateOf(values.joinToString(", ")) }
    OutlinedTextField(text, { text = it; update(it) }, label = { Text("$label — comma separated") }, minLines = 2, modifier = Modifier.fillMaxWidth())
}

private fun parseList(text: String) = text.split(',', '\n', ';').map(String::trim).filter(String::isNotBlank).distinct()
