package com.rajkumar.kpijournal

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.rajkumar.kpijournal.ui.JournalApp
import com.rajkumar.kpijournal.ui.JournalViewModel
import com.rajkumar.kpijournal.voice.SpeechController
import java.io.File

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<JournalViewModel>()
    private lateinit var speech: SpeechController
    private var cameraFile: File? = null

    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) speech.start() else viewModel.showMessage("Microphone permission denied; manual entry remains available")
    }
    private val photoPicker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(8)) { uris ->
        uris.forEach(viewModel::addPhoto)
    }
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) cameraFile?.let(viewModel::addCapturedPhoto) else cameraFile?.delete()
    }
    private val templatePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importTemplate(it, "Imported Excel Format") }
    }
    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(viewModel::restore)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = SpeechController(
            context = this,
            onState = { _, text -> runOnUiThread { viewModel.showMessage(text) } },
            onTranscript = { text -> runOnUiThread { viewModel.updateTranscript(text) } },
        )
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF5BBDB2)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF173B57), secondary = androidx.compose.ui.graphics.Color(0xFF2A9D8F))) {
                JournalApp(
                    viewModel = viewModel,
                    onToggleVoice = {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) speech.toggle()
                        else microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onPickPhotos = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onTakePhoto = {
                        cameraFile = viewModel.createCameraFile()
                        val uri = FileProvider.getUriForFile(this, "$packageName.files", cameraFile!!)
                        camera.launch(uri)
                    },
                    onPickTemplate = { templatePicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },
                    onPickBackup = { restorePicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "*/*")) },
                    onShare = ::shareFile,
                )
            }
        }
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = if (file.extension.equals("xlsx", true)) "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" else "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share ${file.name}"))
    }

    override fun onDestroy() {
        speech.destroy()
        super.onDestroy()
    }
}
