package com.rajkumar.kpijournal.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rajkumar.kpijournal.data.*
import com.rajkumar.kpijournal.excel.*
import com.rajkumar.kpijournal.voice.VoiceParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PendingPhoto(val file: File, val caption: String = "", val category: String = "Other")

class JournalViewModel(application: Application) : AndroidViewModel(application) {
    private val database = JournalDatabase(application)
    private val configStore = ConfigStore(application)
    private val files = FileServices(application, database)
    private val analyzer = ExcelTemplateAnalyzer(application)
    private val exporter = XlsxExporter(application)

    var config by mutableStateOf(configStore.load())
        private set
    var template by mutableStateOf(loadTemplate())
        private set
    var records by mutableStateOf<List<JournalRecord>>(emptyList())
        private set
    var stats by mutableStateOf(DashboardStats())
        private set
    var draft by mutableStateOf(ActivityRecord())
        private set
    var transcript by mutableStateOf("")
        private set
    var pendingPhotos by mutableStateOf<List<PendingPhoto>>(emptyList())
        private set
    var message by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set

    init { refresh() }

    fun showMessage(value: String) { message = value }
    fun updateDraft(value: ActivityRecord) { draft = value }
    fun updateTranscript(value: String, parse: Boolean = false) {
        transcript = value
        if (parse && value.isNotBlank()) draft = VoiceParser(config).parse(value)
    }
    fun parseTranscript() {
        if (transcript.isBlank()) return
        draft = VoiceParser(config).parse(transcript)
        message = "Voice converted to structured fields. Review before saving."
    }

    fun newRecord() {
        draft = ActivityRecord()
        transcript = ""
        pendingPhotos = emptyList()
        message = ""
    }

    fun edit(record: JournalRecord) {
        draft = record.activity
        transcript = record.activity.description
        pendingPhotos = emptyList()
    }

    fun duplicate(record: JournalRecord) {
        draft = record.activity.copy(id = 0, date = java.time.LocalDate.now().toString(), createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis())
        transcript = draft.description
        pendingPhotos = emptyList()
        message = "Duplicated. Review and save as a new record."
    }

    fun saveDraft() = viewModelScope.launch(Dispatchers.IO) {
        if (draft.activityCategory.isBlank()) {
            withContext(Dispatchers.Main) { message = "Select an activity category" }
            return@launch
        }
        val normalized = draft.copy(
            description = draft.description.ifBlank { transcript },
            durationMinutes = if (draft.durationMinutes > 0) draft.durationMinutes else calculateDuration(draft.startTime, draft.stopTime),
        )
        val saved = database.save(normalized)
        pendingPhotos.forEach { pending ->
            database.savePhoto(PhotoAttachment(recordId = saved.id, localPath = pending.file.absolutePath, fileName = pending.file.name, caption = pending.caption, category = pending.category))
        }
        withContext(Dispatchers.Main) {
            newRecord()
            message = "Activity saved offline"
            refresh()
        }
    }

    fun delete(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        database.deleteRecord(id)
        withContext(Dispatchers.Main) { message = "Record deleted"; refresh() }
    }

    fun addPhoto(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { files.importPhoto(uri) }.onSuccess { file ->
            withContext(Dispatchers.Main) { pendingPhotos = pendingPhotos + PendingPhoto(file); message = "Photo attached" }
        }.onFailure { withContext(Dispatchers.Main) { message = it.message ?: "Unable to add photo" } }
    }

    fun addCapturedPhoto(file: File) {
        if (file.exists() && file.length() > 0) {
            pendingPhotos = pendingPhotos + PendingPhoto(file)
            message = "Camera photo attached"
        }
    }

    fun removePendingPhoto(index: Int) {
        pendingPhotos.getOrNull(index)?.file?.delete()
        pendingPhotos = pendingPhotos.filterIndexed { i, _ -> i != index }
    }

    fun updatePendingPhoto(index: Int, caption: String? = null, category: String? = null) {
        pendingPhotos = pendingPhotos.mapIndexed { i, photo ->
            if (i == index) photo.copy(caption = caption ?: photo.caption, category = category ?: photo.category) else photo
        }
    }

    fun createCameraFile(): File = files.createCameraFile()

    fun importTemplate(uri: Uri, name: String = "Imported Excel") = viewModelScope.launch(Dispatchers.IO) {
        busy = true
        runCatching { analyzer.analyze(uri, name) }.onSuccess { profile ->
            configStore.saveTemplateProfile(profile.toJson())
            withContext(Dispatchers.Main) { template = profile; message = "Excel format detected: ${profile.sheets.size} sheets" }
        }.onFailure { withContext(Dispatchers.Main) { message = it.message ?: "Template analysis failed" } }
        busy = false
    }

    fun useSampleTemplate() {
        template = analyzer.analyzeBundledSample()
        configStore.saveTemplateProfile(template.toJson())
        message = "H1 2026 Activities selected as the sample output profile"
    }

    fun updateTemplateSheet(sheetName: String, category: String, headersText: String) {
        val headers = headersText.split('\n', ',', ';').map(String::trim).filter(String::isNotBlank)
        if (headers.isEmpty()) return
        template = template.copy(sheets = template.sheets.map {
            if (it.sheetName == sheetName) it.copy(category = category, headers = headers) else it
        })
        configStore.saveTemplateProfile(template.toJson())
        message = "Excel mapping updated"
    }

    fun export(filter: RecordFilter = RecordFilter(), onReady: (File) -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        busy = true
        runCatching { exporter.export(template, database.records(filter), "KPI_Activities") }
            .onSuccess { withContext(Dispatchers.Main) { message = "Excel exported offline"; onReady(it) } }
            .onFailure { withContext(Dispatchers.Main) { message = it.message ?: "Excel export failed" } }
        busy = false
    }

    fun saveConfig(updated: AppConfig) {
        config = updated
        configStore.save(updated)
        message = "Settings saved"
    }

    fun backup(onReady: (File) -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { files.backupDatabase() }
            .onSuccess { withContext(Dispatchers.Main) { message = "Database backup created"; onReady(it) } }
            .onFailure { withContext(Dispatchers.Main) { message = it.message ?: "Backup failed" } }
    }

    fun restore(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { files.restoreDatabase(uri) }
            .onSuccess { withContext(Dispatchers.Main) { message = "Backup restored"; refresh() } }
            .onFailure { withContext(Dispatchers.Main) { message = it.message ?: "Restore failed" } }
    }

    fun refresh(filter: RecordFilter = RecordFilter()) = viewModelScope.launch(Dispatchers.IO) {
        val list = database.records(filter)
        val dashboard = database.stats()
        withContext(Dispatchers.Main) { records = list; stats = dashboard }
    }

    private fun loadTemplate(): TemplateProfile =
        configStore.loadTemplateProfile()?.let { runCatching { TemplateProfile.fromJson(it) }.getOrNull() }
            ?: analyzer.analyzeBundledSample().also { configStore.saveTemplateProfile(it.toJson()) }

    fun periodFilter(period: String): RecordFilter {
        val today = java.time.LocalDate.now()
        val (start, end) = when (period) {
            "This Month" -> today.withDayOfMonth(1) to today.withDayOfMonth(today.lengthOfMonth())
            "This Quarter" -> {
                val month = ((today.monthValue - 1) / 3) * 3 + 1
                val first = java.time.LocalDate.of(today.year, month, 1)
                first to first.plusMonths(3).minusDays(1)
            }
            "H1" -> java.time.LocalDate.of(today.year, 1, 1) to java.time.LocalDate.of(today.year, 6, 30)
            "H2" -> java.time.LocalDate.of(today.year, 7, 1) to java.time.LocalDate.of(today.year, 12, 31)
            "This Year" -> java.time.LocalDate.of(today.year, 1, 1) to java.time.LocalDate.of(today.year, 12, 31)
            else -> return RecordFilter()
        }
        return RecordFilter(startDate = start.toString(), endDate = end.toString())
    }

    private fun calculateDuration(start: String, stop: String): Int = try {
        val from = java.time.LocalTime.parse(start)
        val to = java.time.LocalTime.parse(stop)
        var value = java.time.Duration.between(from, to).toMinutes()
        if (value < 0) value += 24 * 60
        value.toInt()
    } catch (_: Exception) { 0 }
}
