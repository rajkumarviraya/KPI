package com.rajkumar.kpijournal.excel

import android.content.Context
import com.rajkumar.kpijournal.data.JournalRecord
import java.io.File
import java.io.OutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class XlsxExporter(private val context: Context) {
    fun export(profile: TemplateProfile, records: List<JournalRecord>, label: String = "KPI_Activities"): File {
        val folder = File(context.filesDir, "exports").apply { mkdirs() }
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))
        val file = File(folder, "${safe(label)}_$stamp.xlsx")
        file.outputStream().use { writeWorkbook(it, profile, records) }
        exportPhotoCopies(file, records)
        return file
    }

    private fun writeWorkbook(output: OutputStream, profile: TemplateProfile, records: List<JournalRecord>) {
        ZipOutputStream(output.buffered()).use { zip ->
            zip.write("[Content_Types].xml", contentTypes(profile.sheets.size))
            zip.write("_rels/.rels", ROOT_RELS)
            zip.write("docProps/core.xml", coreProperties())
            zip.write("docProps/app.xml", appProperties(profile.sheets.map { it.sheetName }))
            zip.write("xl/workbook.xml", workbookXml(profile.sheets))
            zip.write("xl/_rels/workbook.xml.rels", workbookRels(profile.sheets.size))
            zip.write("xl/styles.xml", STYLES)
            profile.sheets.forEachIndexed { index, sheet ->
                val rows = if (sheet.category.isBlank()) records else records.filter { it.activity.activityCategory.equals(sheet.category, true) }
                zip.write("xl/worksheets/sheet${index + 1}.xml", worksheetXml(profile.name, sheet, rows))
            }
        }
    }

    private fun worksheetXml(profileName: String, profile: SheetProfile, records: List<JournalRecord>): String {
        val headers = profile.headers.ifEmpty { ExcelTemplateAnalyzer.DEFAULT_HEADERS }
        val headerRow = profile.headerRow.coerceIn(2, 20)
        val lastColumn = columnName(headers.size)
        val dataStart = headerRow + 1
        val lastRow = maxOf(headerRow, dataStart + records.size - 1)
        val rows = buildString {
            append(row(1, listOf("${profileName} • ${profile.sheetName}"), style = 2))
            append(row(2, listOf("Generated offline by KPI Voice Journal. Headers follow the active Excel template profile."), style = 3))
            append(row(headerRow, headers, style = 1))
            records.forEachIndexed { index, record ->
                append(row(dataStart + index, headers.map { FieldMapper.value(record, it) }, style = 0))
            }
        }
        val columns = headers.mapIndexed { index, header ->
            val width = when {
                normalize(header).contains("description") || normalize(header).contains("resolution") -> 38
                normalize(header).contains("caption") || normalize(header).contains("notes") -> 30
                normalize(header).contains("project") || normalize(header).contains("customer") -> 24
                else -> maxOf(14, minOf(24, header.length + 3))
            }
            """<col min="${index + 1}" max="${index + 1}" width="$width" customWidth="1"/>"""
        }.joinToString("")
        return XML_HEADER + """
            <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
              <sheetViews><sheetView workbookViewId="0"><pane ySplit="$headerRow" topLeftCell="A${headerRow + 1}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
              <cols>$columns</cols>
              <sheetData>$rows</sheetData>
              <autoFilter ref="A$headerRow:$lastColumn$lastRow"/>
            </worksheet>
        """.trimIndent()
    }

    private fun row(number: Int, values: List<String>, style: Int): String =
        """<row r="$number">${values.mapIndexed { index, value ->
            val ref = "${columnName(index + 1)}$number"
            """<c r="$ref" s="$style" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>"""
        }.joinToString("")}</row>"""

    private fun contentTypes(count: Int) = XML_HEADER + """
        <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
          <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
          <Default Extension="xml" ContentType="application/xml"/>
          <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
          <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
          <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
          <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
          ${(1..count).joinToString("") { """<Override PartName="/xl/worksheets/sheet$it.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""" }}
        </Types>
    """.trimIndent()

    private fun workbookXml(sheets: List<SheetProfile>) = XML_HEADER + """
        <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
          <sheets>${sheets.mapIndexed { index, sheet -> """<sheet name="${xml(sheet.sheetName.take(31))}" sheetId="${index + 1}" r:id="rId${index + 1}"/>""" }.joinToString("")}</sheets>
        </workbook>
    """.trimIndent()

    private fun workbookRels(count: Int) = XML_HEADER + """
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
          ${(1..count).joinToString("") { """<Relationship Id="rId$it" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$it.xml"/>""" }}
          <Relationship Id="rId${count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
        </Relationships>
    """.trimIndent()

    private fun appProperties(sheetNames: List<String>) = XML_HEADER + """
        <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
          xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
          <Application>KPI Voice Journal</Application>
          <TitlesOfParts><vt:vector size="${sheetNames.size}" baseType="lpstr">${sheetNames.joinToString("") { "<vt:lpstr>${xml(it)}</vt:lpstr>" }}</vt:vector></TitlesOfParts>
        </Properties>
    """.trimIndent()

    private fun coreProperties() = XML_HEADER + """
        <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
          xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <dc:title>KPI Activities</dc:title><dc:creator>KPI Voice Journal</dc:creator>
          <dcterms:created xsi:type="dcterms:W3CDTF">${java.time.Instant.now()}</dcterms:created>
        </cp:coreProperties>
    """.trimIndent()

    private fun exportPhotoCopies(workbook: File, records: List<JournalRecord>) {
        val photos = records.flatMap { it.photos }
        if (photos.isEmpty()) return
        val folder = File(workbook.parentFile, workbook.nameWithoutExtension + "_photos").apply { mkdirs() }
        photos.forEach { photo ->
            val source = File(photo.localPath)
            if (source.exists()) source.copyTo(File(folder, "${photo.recordId}_${safe(photo.fileName)}"), overwrite = true)
        }
    }

    private fun ZipOutputStream.write(path: String, content: String) {
        putNextEntry(ZipEntry(path))
        write(content.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private fun columnName(number: Int): String {
        var n = number
        var result = ""
        while (n > 0) { n--; result = ('A'.code + n % 26).toChar() + result; n /= 26 }
        return result
    }

    private fun xml(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun safe(value: String) = value.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
    private fun normalize(value: String) = value.lowercase().replace(Regex("[^a-z0-9]"), "")

    companion object {
        private const val XML_HEADER = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"""
        private val ROOT_RELS = XML_HEADER + """
          <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
            <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
            <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
          </Relationships>
        """.trimIndent()
        private val STYLES = XML_HEADER + """
          <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
            <fonts count="3">
              <font><sz val="10"/><name val="Aptos"/></font>
              <font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Aptos"/></font>
              <font><b/><color rgb="FFFFFFFF"/><sz val="16"/><name val="Aptos Display"/></font>
            </fonts>
            <fills count="4">
              <fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
              <fill><patternFill patternType="solid"><fgColor rgb="FF2B6F91"/><bgColor indexed="64"/></patternFill></fill>
              <fill><patternFill patternType="solid"><fgColor rgb="FF173B57"/><bgColor indexed="64"/></patternFill></fill>
            </fills>
            <borders count="2"><border/><border><bottom style="thin"><color rgb="FFD8E1E5"/></bottom></border></borders>
            <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
            <cellXfs count="4">
              <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
              <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
              <xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
              <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1"/>
            </cellXfs>
            <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
          </styleSheet>
        """.trimIndent()
    }
}

object FieldMapper {
    fun value(record: JournalRecord, header: String): String {
        val a = record.activity
        val photos = record.photos
        return when (normalize(header)) {
            "date", "activitydate" -> a.date
            "projectname", "project" -> a.projectName
            "purpose" -> a.purpose.ifBlank { a.activityCategory }
            "remoteonsite", "mode", "deliverymode" -> a.remoteOnsite
            "sind", "partner", "integrator" -> a.siNd
            "contactperson", "contactpersion" -> a.contactPerson
            "customername", "customer" -> a.customerName
            "country" -> a.country
            "description" -> a.description
            "enhanceddescription", "professionaldescription" -> a.enhancedDescription
            "product" -> a.product
            "channel" -> a.channel
            "starttime" -> a.startTime
            "stoptime", "endtime" -> a.stopTime
            "averagetime", "averagetimeduration", "duration", "average", "averagae" -> duration(a.durationMinutes)
            "status" -> a.status
            "activitycategory", "category" -> a.activityCategory
            "issuefaultdescription", "faultdescription", "issue" -> a.faultDescription
            "resolutionactiontaken", "resolution", "actiontaken" -> a.resolution
            "photoavailable" -> if (photos.isEmpty()) "No" else "Yes"
            "photofilename", "photofilenames" -> photos.joinToString("; ") { it.fileName }
            "photocaption", "photocaptions" -> photos.joinToString("; ") { it.caption }
            "notes", "photonotes" -> a.notes
            else -> ""
        }
    }

    private fun normalize(value: String) = value.lowercase().replace(Regex("[^a-z0-9]"), "")
    private fun duration(minutes: Int) = "${minutes / 1440} days %02d:%02d".format((minutes % 1440) / 60, minutes % 60)
}
