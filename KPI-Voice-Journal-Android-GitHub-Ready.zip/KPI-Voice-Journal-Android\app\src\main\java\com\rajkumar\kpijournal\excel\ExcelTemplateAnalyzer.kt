package com.rajkumar.kpijournal.excel

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipFile

class ExcelTemplateAnalyzer(private val context: Context) {
    fun analyze(uri: Uri, displayName: String = "Imported Excel"): TemplateProfile {
        val temp = File.createTempFile("template_", ".xlsx", context.cacheDir)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open Excel file" }
            temp.outputStream().use(input::copyTo)
        }
        return try { analyze(temp, displayName) } finally { temp.delete() }
    }

    fun analyze(file: File, displayName: String = file.name): TemplateProfile {
        ZipFile(file).use { zip ->
            val shared = readSharedStrings(zip)
            val sheetNames = readSheetNames(zip)
            val sheets = zip.entries().asSequence()
                .filter { it.name.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }
                .sortedBy { it.name }
                .mapIndexed { index, entry ->
                    val rows = parseRows(zip.getInputStream(entry).bufferedReader().readText(), shared)
                    val candidate = rows.maxByOrNull { (_, cells) -> headerScore(cells) }
                    val headers = candidate?.second?.dropLastWhile(String::isBlank).orEmpty()
                    val name = sheetNames.getOrElse(index) { "Sheet ${index + 1}" }
                    SheetProfile(
                        sheetName = name,
                        category = guessCategory(name, headers),
                        headerRow = candidate?.first ?: 1,
                        headers = if (headers.size >= 3) headers else DEFAULT_HEADERS,
                    )
                }.toList()
            require(sheets.isNotEmpty()) { "No Excel worksheets were detected" }
            return TemplateProfile(
                name = displayName.substringBeforeLast("."),
                sourceFileName = displayName,
                sheets = sheets,
            )
        }
    }

    fun analyzeBundledSample(): TemplateProfile {
        val file = File(context.filesDir, "H1_2026_Activities_sample.xlsx")
        if (!file.exists()) context.assets.open("H1_2026_Activities_sample.xlsx").use { input ->
            file.outputStream().use(input::copyTo)
        }
        return analyze(file, "H1 2026 Activities — Sample Output")
    }

    private fun readSheetNames(zip: ZipFile): List<String> {
        val entry = zip.getEntry("xl/workbook.xml") ?: return emptyList()
        val xml = zip.getInputStream(entry).bufferedReader().readText()
        return Regex("""<sheet[^>]*name="([^"]+)"""").findAll(xml).map { unescape(it.groupValues[1]) }.toList()
    }

    private fun readSharedStrings(zip: ZipFile): List<String> {
        val entry = zip.getEntry("xl/sharedStrings.xml") ?: return emptyList()
        val xml = zip.getInputStream(entry).bufferedReader().readText()
        return Regex("""<si>(.*?)</si>""", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { match ->
            Regex("""<t[^>]*>(.*?)</t>""", RegexOption.DOT_MATCHES_ALL)
                .findAll(match.groupValues[1]).joinToString("") { unescape(it.groupValues[1]) }
        }.toList()
    }

    private fun parseRows(xml: String, shared: List<String>): List<Pair<Int, List<String>>> {
        return Regex("""<row[^>]*r="(\d+)"[^>]*>(.*?)</row>""", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { row ->
            val values = sortedMapOf<Int, String>()
            Regex("""<c[^>]*r="([A-Z]+)\d+"([^>]*)>(.*?)</c>""", RegexOption.DOT_MATCHES_ALL).findAll(row.groupValues[2]).forEach { cell ->
                val column = columnIndex(cell.groupValues[1])
                val attrs = cell.groupValues[2]
                val body = cell.groupValues[3]
                val inline = Regex("""<t[^>]*>(.*?)</t>""", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)
                val raw = Regex("""<v>(.*?)</v>""", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1).orEmpty()
                values[column] = when {
                    inline != null -> unescape(inline)
                    """t="s"""" in attrs -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                    else -> unescape(raw)
                }
            }
            val last = values.keys.maxOrNull() ?: 0
            row.groupValues[1].toInt() to List(last + 1) { values[it].orEmpty().trim() }
        }.take(40).toList()
    }

    private fun headerScore(cells: List<String>): Int {
        val normalized = cells.map(::normalize)
        return normalized.count { it in KNOWN_HEADERS } * 10 + cells.count(String::isNotBlank)
    }

    private fun guessCategory(name: String, headers: List<String>): String {
        val text = "$name ${headers.joinToString(" ")}".lowercase()
        return when {
            "training" in text -> "Training"
            "technical" in text || "support" in text -> "Technical Support"
            "project" in text || "delivery" in text -> "Project Delivery Support"
            else -> ""
        }
    }

    private fun columnIndex(letters: String): Int =
        letters.fold(0) { total, c -> total * 26 + (c - 'A' + 1) } - 1

    private fun normalize(value: String) = value.lowercase().replace(Regex("[^a-z0-9]"), "")
    private fun unescape(value: String) = value
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'")

    companion object {
        val DEFAULT_HEADERS = listOf(
            "Date", "Project Name", "Purpose", "Remote / Onsite", "SI / ND", "Contact Person",
            "Customer Name", "Country", "Description", "Enhanced Description", "Product", "Channel",
            "Start Time", "Stop Time", "Average Time / Duration", "Status", "Activity Category",
            "Issue / Fault Description", "Resolution / Action Taken", "Photo Available",
            "Photo File Name", "Photo Caption", "Notes",
        )
        private val KNOWN_HEADERS = (DEFAULT_HEADERS + listOf(
            "Remote/Onsite", "SI/ND", "Contact Persion", "startTime", "stopTime", "Averagae", "status",
        )).map { it.lowercase().replace(Regex("[^a-z0-9]"), "") }.toSet()
    }
}
