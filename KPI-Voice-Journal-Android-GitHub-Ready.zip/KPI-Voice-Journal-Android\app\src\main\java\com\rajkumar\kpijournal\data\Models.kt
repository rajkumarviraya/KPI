package com.rajkumar.kpijournal.data

data class ActivityRecord(
    val id: Long = 0,
    val date: String = java.time.LocalDate.now().toString(),
    val projectName: String = "",
    val purpose: String = "",
    val remoteOnsite: String = "",
    val siNd: String = "",
    val contactPerson: String = "",
    val customerName: String = "",
    val country: String = "",
    val description: String = "",
    val enhancedDescription: String = "",
    val product: String = "",
    val channel: String = "",
    val startTime: String = "",
    val stopTime: String = "",
    val durationMinutes: Int = 0,
    val status: String = "",
    val activityCategory: String = "",
    val faultDescription: String = "",
    val resolution: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

data class PhotoAttachment(
    val id: Long = 0,
    val recordId: Long,
    val localPath: String,
    val fileName: String,
    val caption: String = "",
    val category: String = "Other",
)

data class JournalRecord(
    val activity: ActivityRecord,
    val photos: List<PhotoAttachment> = emptyList(),
)

data class DashboardStats(
    val total: Int = 0,
    val today: Int = 0,
    val month: Int = 0,
    val support: Int = 0,
    val project: Int = 0,
    val training: Int = 0,
    val solved: Int = 0,
    val pending: Int = 0,
    val countries: Int = 0,
    val products: Int = 0,
    val totalMinutes: Int = 0,
)

data class RecordFilter(
    val query: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val country: String = "",
    val product: String = "",
    val category: String = "",
    val status: String = "",
)
