# Future Maintenance

## Normal changes — no coding

Use Settings to edit dropdown lists and Excel header mappings. Import a changed `.xlsx` whenever sheet names or columns change.

## Add a header alias

Update `FieldMapper.value()` in `excel/XlsxExporter.kt`. Normalize the header and map it to one stable `ActivityRecord` field.

## Add a stored field

1. Add it to `ActivityRecord`.
2. Increase database version and add a migration in `JournalDatabase`.
3. Add the editor control.
4. Add aliases to `FieldMapper`.

## AI enhancement later

Keep `VoiceParser` as the offline fallback. Add an optional online enhancer behind an interface and require explicit user enablement before sending text externally.

## Release

Increment `versionCode` and `versionName`, run the checklist, then create a signed release APK/AAB with a private keystore. Never commit the keystore.
