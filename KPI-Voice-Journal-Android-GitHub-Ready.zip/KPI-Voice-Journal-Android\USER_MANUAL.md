# User Manual

## Daily voice workflow

1. Open the app and tap the microphone.
2. Speak the customer, country, work type, product, issue, resolution, start/stop times and status.
3. Tap again to stop.
4. Tap **Extract fields**.
5. Review every detected field. Missing information stays blank.
6. Attach camera/gallery photos and add captions.
7. Tap **Save offline**.

Example:

> I got a call from XYZ Company in UAE. Technical support for LED. I guided them to restart the controller and check the signal cable. Start time 10:00 AM, stop time 10:30 AM. Status solved.

## Manual entry

Tap **Manual entry** from Home. Fields and dropdowns can be completed without voice.

## Records

- Search customer, project or description.
- Filter by category or status.
- Edit, duplicate or delete records.

## Excel export

1. Open **Excel**.
2. Confirm the active format.
3. Tap **Export all records to Excel**.
4. Choose WhatsApp, Email, Teams or Files from Android sharing.

Photo file names and captions are written into Excel. Local photo copies are also placed beside the generated workbook in the app export storage.

## When your Excel format changes

Import the revised workbook. The detector identifies headers and sheets. Review the mapping in Settings. The H1 workbook remains the sample; it is not allowed to lock the app to old headers.

## Backup

Use **Settings → Create and share database backup**. Restore only a backup produced by this app. Keep at least one backup outside the phone.
