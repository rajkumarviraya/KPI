package com.rajkumar.kpijournal

import com.rajkumar.kpijournal.data.AppConfig
import com.rajkumar.kpijournal.voice.VoiceParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceParserTest {
    private val config = AppConfig(
        products = listOf("LED", "IFP", "Digital Signage"),
        countries = listOf("UAE", "Qatar", "Oman"),
        categories = listOf("Technical Support", "Project Delivery Support", "Training"),
        modes = listOf("Remote", "Onsite"),
        siNd = listOf("SI", "ND"),
        channels = listOf("Phone Call", "WhatsApp", "Site Visit"),
        statuses = listOf("Solved", "Pending", "Completed"),
        photoCategories = listOf("Other"),
    )

    @Test
    fun parsesSupportExampleWithoutInventingFields() {
        val result = VoiceParser(config).parse(
            "I got a call from XYZ Company in UAE. Technical support for LED configuration issue. " +
                "I explained restart controller and check cable. Start time 10:00 AM, stop time 10:30 AM. Status solved."
        )
        assertEquals("Technical Support", result.activityCategory)
        assertEquals("UAE", result.country)
        assertEquals("LED", result.product)
        assertEquals("Remote", result.remoteOnsite)
        assertEquals("10:00", result.startTime)
        assertEquals("10:30", result.stopTime)
        assertEquals(30, result.durationMinutes)
        assertEquals("Solved", result.status)
        assertTrue(result.enhancedDescription.contains("Provided"))
    }
}
