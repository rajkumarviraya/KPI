# Installation

## Install a built APK

1. Copy `app-debug.apk` to the Samsung phone.
2. Open the APK from My Files.
3. If prompted, allow installation from that file source.
4. Install and open **KPI Voice Journal**.
5. Grant microphone permission when using voice.
6. Grant camera/photo access only when adding evidence.

## Recommended Samsung setup

- Android 14 or later.
- Install an English offline speech language pack in the phone's speech-recognition settings.
- Exclude the app from aggressive storage cleanup if records will be kept for years.
- Create regular database backups from Settings and store them separately.

## First use

The application initially selects the bundled `H1 2026 Activities` sample output profile. Import a revised Excel workbook at any time from the Excel screen.
