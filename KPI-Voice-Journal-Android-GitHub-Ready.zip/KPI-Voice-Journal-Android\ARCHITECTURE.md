# Architecture

## Presentation

- Jetpack Compose screens in `ui/JournalApp.kt`.
- `JournalViewModel` owns application state and coordinates use cases.

## Domain

- `ActivityRecord`, `PhotoAttachment`, `JournalRecord`, filters and dashboard metrics.
- `VoiceParser` performs deterministic offline extraction and description enhancement.
- `FieldMapper` maps normalized Excel headers to record fields.

## Data

- `JournalDatabase`: local SQLite database.
- `ConfigStore`: editable lists and selected template profile in private preferences.
- `FileServices`: private photo storage and database backup/restore.

## Excel

- `ExcelTemplateAnalyzer`: reads `.xlsx` ZIP/XML, worksheet names, header candidates and columns without uploading the file.
- `TemplateProfile`: independent, editable mapping model.
- `XlsxExporter`: dependency-free offline `.xlsx` writer with filtering, frozen headers, autofilters and widths.

## Key separation

Historical records use a stable internal data model. Excel headers are a configurable output adapter. Importing a changed Excel file updates only the adapter, never the database schema or historical records.
