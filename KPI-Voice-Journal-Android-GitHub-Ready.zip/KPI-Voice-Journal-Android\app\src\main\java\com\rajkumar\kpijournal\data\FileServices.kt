package com.rajkumar.kpijournal.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class FileServices(private val context: Context, private val database: JournalDatabase) {
    fun createCameraFile(): File =
        File(context.filesDir, "photos").apply { mkdirs() }
            .resolve("camera_${System.currentTimeMillis()}.jpg")

    fun importPhoto(uri: Uri): File {
        val folder = File(context.filesDir, "photos").apply { mkdirs() }
        val extension = context.contentResolver.getType(uri)?.substringAfterLast('/')?.let { ".$it" } ?: ".jpg"
        val file = File(folder, "photo_${System.currentTimeMillis()}$extension")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to read photo" }
            file.outputStream().use(input::copyTo)
        }
        return file
    }

    fun backupDatabase(): File {
        database.close()
        val folder = File(context.filesDir, "backups").apply { mkdirs() }
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
        return database.databaseFile().copyTo(File(folder, "kpi_journal_$stamp.db"), overwrite = true)
    }

    fun restoreDatabase(uri: Uri) {
        database.close()
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to read backup" }
            database.databaseFile().outputStream().use(input::copyTo)
        }
    }
}
