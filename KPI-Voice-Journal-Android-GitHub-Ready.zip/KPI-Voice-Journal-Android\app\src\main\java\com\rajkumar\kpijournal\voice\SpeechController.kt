package com.rajkumar.kpijournal.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class SpeechController(
    context: Context,
    private val onState: (Boolean, String) -> Unit,
    private val onTranscript: (String) -> Unit,
) : RecognitionListener {
    private val recognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
        setRecognitionListener(this@SpeechController)
    }
    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
    }
    private var listening = false

    fun toggle() {
        if (listening) stop() else start()
    }

    fun start() {
        listening = true
        onState(true, "Listening… tap again to stop")
        recognizer.startListening(intent)
    }

    fun stop() {
        recognizer.stopListening()
        listening = false
        onState(false, "Processing speech…")
    }

    fun destroy() = recognizer.destroy()

    override fun onReadyForSpeech(params: Bundle?) = onState(true, "Speak now")
    override fun onBeginningOfSpeech() = onState(true, "Recording")
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { listening = false; onState(false, "Processing speech…") }
    override fun onError(error: Int) {
        listening = false
        val message = when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Offline speech model unavailable; use manual entry"
            SpeechRecognizer.ERROR_NO_MATCH -> "No clear speech detected; tap and try again"
            else -> "Voice recognition stopped; you can type manually"
        }
        onState(false, message)
    }
    override fun onResults(results: Bundle?) {
        listening = false
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        if (text.isNotBlank()) onTranscript(text)
        onState(false, if (text.isBlank()) "No speech detected" else "Transcript ready")
    }
    override fun onPartialResults(partialResults: Bundle?) {
        partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onTranscript)
    }
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
}
