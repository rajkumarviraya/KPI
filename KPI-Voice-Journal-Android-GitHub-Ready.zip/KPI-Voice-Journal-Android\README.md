# KPI Voice Journal — Offline Android App

Native Kotlin/Jetpack Compose application for a MEA Technical Support Engineer. It stores all records and photos locally and exports `.xlsx` files without cloud services.

## Important Excel behavior

`H1_2026_Activities_sample.xlsx` is bundled as a **sample final-output profile only**. It is never treated as a permanent schema.

When the workbook format changes:

1. Open **Excel** in the app.
2. Tap **Import changed Excel format**.
3. Select the revised `.xlsx`.
4. The app detects worksheet names, likely header rows and headers.
5. Review sheet-to-category mapping under **Settings → Excel header mapping**.
6. Export. Existing records remain untouched and are filled into the new headers through aliases.

Headers can also be edited manually, one per line. Unknown headers remain blank instead of inventing data.

## Features

- Android 14+; target SDK 35.
- Offline SQLite database using platform `SQLiteOpenHelper`.
- Large start/stop microphone control using Android `SpeechRecognizer` with offline preference.
- Rule-based offline transcript parsing and management-friendly description enhancement.
- Manual editor for all KPI fields.
- Camera and Android Photo Picker; multiple photos per record; captions and categories.
- Search, category/status filters, edit, duplicate and delete confirmation.
- Offline dashboard.
- Dynamic three-sheet or custom-sheet Excel export.
- Database backup/restore.
- Editable product, country, status, category, channel and Excel header configuration.
- System light/dark theme.

## Open and build

Open this folder in Android Studio:

1. Install Android Studio with Android SDK 35.
2. Open `android-kpi-journal`.
3. Allow Gradle sync.
4. Select a Samsung S25 or Android 14+ device.
5. Run the `app` configuration.
6. Build APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Debug APK output:

`app/build/outputs/apk/debug/app-debug.apk`

Release signing must use your own private keystore.

## Privacy

No analytics, cloud database or web API is included. Speech uses the Android recognizer and requests offline recognition. Availability of an offline language pack depends on the Samsung/Google speech service installed on the device; manual entry always remains available.
