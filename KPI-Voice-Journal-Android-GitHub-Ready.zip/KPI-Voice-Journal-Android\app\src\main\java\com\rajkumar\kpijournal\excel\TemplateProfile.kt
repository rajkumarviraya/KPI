package com.rajkumar.kpijournal.excel

import org.json.JSONArray
import org.json.JSONObject

data class SheetProfile(
    val sheetName: String,
    val category: String,
    val headerRow: Int,
    val headers: List<String>,
)

data class TemplateProfile(
    val name: String,
    val sourceFileName: String,
    val sheets: List<SheetProfile>,
    val detectedAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): String = JSONObject().apply {
        put("name", name)
        put("sourceFileName", sourceFileName)
        put("detectedAt", detectedAt)
        put("sheets", JSONArray(sheets.map { sheet ->
            JSONObject().apply {
                put("sheetName", sheet.sheetName)
                put("category", sheet.category)
                put("headerRow", sheet.headerRow)
                put("headers", JSONArray(sheet.headers))
            }
        }))
    }.toString()

    companion object {
        fun fromJson(text: String): TemplateProfile {
            val root = JSONObject(text)
            val array = root.getJSONArray("sheets")
            return TemplateProfile(
                name = root.optString("name", "Excel profile"),
                sourceFileName = root.optString("sourceFileName"),
                detectedAt = root.optLong("detectedAt"),
                sheets = List(array.length()) { index ->
                    val item = array.getJSONObject(index)
                    val headers = item.getJSONArray("headers")
                    SheetProfile(
                        sheetName = item.getString("sheetName"),
                        category = item.optString("category"),
                        headerRow = item.optInt("headerRow", 1),
                        headers = List(headers.length()) { headers.getString(it) },
                    )
                },
            )
        }
    }
}
