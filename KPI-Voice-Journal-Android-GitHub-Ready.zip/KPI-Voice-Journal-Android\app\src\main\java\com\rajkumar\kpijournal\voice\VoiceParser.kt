package com.rajkumar.kpijournal.voice

import com.rajkumar.kpijournal.data.ActivityRecord
import com.rajkumar.kpijournal.data.AppConfig
import java.time.Duration
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale

class VoiceParser(private val config: AppConfig) {
    fun parse(transcript: String): ActivityRecord {
        val text = transcript.trim()
        val lower = text.lowercase(Locale.ROOT)
        val category = when {
            listOf("training", "trained", "workshop").any(lower::contains) -> "Training"
            listOf("project", "installation", "installed", "commissioning", "site").any(lower::contains) -> "Project Delivery Support"
            else -> "Technical Support"
        }
        val product = detect(text, config.products)
        val country = detect(text, config.countries)
        val mode = when {
            listOf("site", "onsite", "visited", "installation").any(lower::contains) -> "Onsite"
            listOf("remote", "call", "whatsapp", "teams", "email").any(lower::contains) -> "Remote"
            else -> ""
        }
        val channel = config.channels.firstOrNull { lower.contains(it.lowercase()) }
            ?: when {
                "call" in lower || "phone" in lower -> "Phone Call"
                "whatsapp" in lower -> "WhatsApp"
                "email" in lower -> "Email"
                "teams" in lower -> "Teams"
                "site" in lower || "visited" in lower -> "Site Visit"
                else -> ""
            }
        val status = when {
            listOf("solved", "resolved", "fixed").any(lower::contains) -> "Solved"
            "pending" in lower -> "Pending"
            "escalated" in lower -> "Escalated"
            "completed" in lower || "finished" in lower -> "Completed"
            else -> ""
        }
        val times = TIME_REGEX.findAll(lower).map {
            normalizeTime(it.groupValues[1].ifBlank { it.groupValues[3] }, it.groupValues[2].ifBlank { it.groupValues[4] })
        }.filterNotNull().toList()
        val start = times.getOrNull(0).orEmpty()
        val stop = times.getOrNull(1).orEmpty()
        val duration = durationMinutes(start, stop)
        val customer = extract(text, """(?:call\s+from|from|for|at)\s+([A-Za-z0-9&.' -]{2,50}?)(?=\s+(?:from|in|regarding|about|for|product|this\s+is|with)\b|[.,]|$)""")
        val project = extract(text, """(?:project\s+(?:is|name)?|at)\s+([A-Za-z0-9&.' -]{2,50}?)(?=\s+(?:in|for|with|product)\b|[.,]|$)""")
        val resolution = sentenceAfter(text, listOf("I explained", "guided", "resolution", "action taken", "solved by"))
        val fault = sentenceAfter(text, listOf("issue", "fault", "problem"))
        return ActivityRecord(
            projectName = project,
            purpose = category,
            remoteOnsite = mode,
            customerName = customer,
            country = country,
            description = text,
            enhancedDescription = enhance(text, category, customer, country, product, mode),
            product = product,
            channel = channel,
            startTime = start,
            stopTime = stop,
            durationMinutes = duration,
            status = status,
            activityCategory = category,
            faultDescription = fault,
            resolution = resolution,
        )
    }

    fun enhance(raw: String, category: String, customer: String, country: String, product: String, mode: String): String {
        val prefix = when (category) {
            "Training" -> "Delivered technical training"
            "Project Delivery Support" -> "Provided project delivery and installation support"
            else -> "Provided ${mode.lowercase().ifBlank { "technical" }} technical support"
        }
        val who = if (customer.isBlank()) "" else " to $customer"
        val where = if (country.isBlank()) "" else " in $country"
        val forProduct = if (product.isBlank()) "" else " for $product"
        val cleaned = raw.trim().replace(Regex("\\s+"), " ").replaceFirstChar { it.uppercase() }.trimEnd('.', ' ') + "."
        return "$prefix$who$where$forProduct. $cleaned"
            .replace("..", ".")
            .replace(Regex("\\s+"), " ")
            .take(600)
    }

    private fun detect(text: String, values: List<String>): String =
        values.sortedByDescending(String::length).firstOrNull { Regex("\\b${Regex.escape(it)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) }.orEmpty()

    private fun extract(text: String, pattern: String): String =
        Regex(pattern, RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.trim().orEmpty()

    private fun sentenceAfter(text: String, keys: List<String>): String {
        val lower = text.lowercase()
        val match = keys.map { it to lower.indexOf(it.lowercase()) }.filter { it.second >= 0 }.minByOrNull { it.second } ?: return ""
        return text.substring(match.second).substringBefore('.').trim().take(300)
    }

    private fun normalizeTime(raw: String, suffix: String): String? {
        val cleaned = raw.trim().replace('.', ':')
        val patterns = if (suffix.isBlank()) listOf("H:mm", "H") else listOf("h:mm a", "h a")
        for (pattern in patterns) try {
            val value = "$cleaned ${suffix.uppercase()}".trim()
            return LocalTime.parse(value, DateTimeFormatter.ofPattern(pattern, Locale.US)).format(DateTimeFormatter.ofPattern("HH:mm"))
        } catch (_: DateTimeParseException) { }
        return null
    }

    private fun durationMinutes(start: String, stop: String): Int =
        try {
            val a = LocalTime.parse(start)
            var b = LocalTime.parse(stop)
            var minutes = Duration.between(a, b).toMinutes()
            if (minutes < 0) minutes += 24 * 60
            minutes.toInt()
        } catch (_: Exception) { 0 }

    companion object {
        private val TIME_REGEX = Regex("""\b(?:(\d{1,2}:\d{2})\s*(a\.?m\.?|p\.?m\.?)?|(\d{1,2})\s*(a\.?m\.?|p\.?m\.?))\b""", RegexOption.IGNORE_CASE)
    }
}
