package com.rajkumar.kpijournal.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

class JournalDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val appContext = context.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE activities(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                project_name TEXT,
                purpose TEXT,
                remote_onsite TEXT,
                si_nd TEXT,
                contact_person TEXT,
                customer_name TEXT,
                country TEXT,
                description TEXT,
                enhanced_description TEXT,
                product TEXT,
                channel TEXT,
                start_time TEXT,
                stop_time TEXT,
                duration_minutes INTEGER NOT NULL DEFAULT 0,
                status TEXT,
                activity_category TEXT,
                fault_description TEXT,
                resolution TEXT,
                notes TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )""".trimIndent()
        )
        db.execSQL(
            """CREATE TABLE photos(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id INTEGER NOT NULL,
                local_path TEXT NOT NULL,
                file_name TEXT NOT NULL,
                caption TEXT,
                category TEXT,
                FOREIGN KEY(record_id) REFERENCES activities(id) ON DELETE CASCADE
            )""".trimIndent()
        )
        db.execSQL("CREATE INDEX idx_activities_date ON activities(date)")
        db.execSQL("CREATE INDEX idx_activities_category ON activities(activity_category)")
        db.execSQL("CREATE INDEX idx_photos_record ON photos(record_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.enableWriteAheadLogging()
    }

    fun save(record: ActivityRecord): ActivityRecord {
        val values = record.toValues()
        val now = System.currentTimeMillis()
        return if (record.id == 0L) {
            values.put("created_at", now)
            values.put("updated_at", now)
            record.copy(id = writableDatabase.insertOrThrow("activities", null, values), createdAt = now, updatedAt = now)
        } else {
            values.put("updated_at", now)
            writableDatabase.update("activities", values, "id=?", arrayOf(record.id.toString()))
            record.copy(updatedAt = now)
        }
    }

    fun savePhoto(photo: PhotoAttachment): PhotoAttachment {
        val values = ContentValues().apply {
            put("record_id", photo.recordId)
            put("local_path", photo.localPath)
            put("file_name", photo.fileName)
            put("caption", photo.caption)
            put("category", photo.category)
        }
        return if (photo.id == 0L) {
            photo.copy(id = writableDatabase.insertOrThrow("photos", null, values))
        } else {
            writableDatabase.update("photos", values, "id=?", arrayOf(photo.id.toString()))
            photo
        }
    }

    fun records(filter: RecordFilter = RecordFilter()): List<JournalRecord> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (filter.query.isNotBlank()) {
            clauses += "(project_name LIKE ? OR customer_name LIKE ? OR description LIKE ? OR enhanced_description LIKE ?)"
            repeat(4) { args += "%${filter.query}%" }
        }
        listOf(
            "date>=?" to filter.startDate,
            "date<=?" to filter.endDate,
            "country=?" to filter.country,
            "product=?" to filter.product,
            "activity_category=?" to filter.category,
            "status=?" to filter.status,
        ).forEach { (sql, value) -> if (value.isNotBlank()) { clauses += sql; args += value } }
        val where = if (clauses.isEmpty()) "" else "WHERE ${clauses.joinToString(" AND ")}"
        return readableDatabase.rawQuery("SELECT * FROM activities $where ORDER BY date DESC,id DESC", args.toTypedArray()).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    val activity = cursor.toActivity()
                    add(JournalRecord(activity, photos(activity.id)))
                }
            }
        }
    }

    fun record(id: Long): JournalRecord? =
        readableDatabase.rawQuery("SELECT * FROM activities WHERE id=?", arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) null else JournalRecord(c.toActivity(), photos(id))
        }

    fun photos(recordId: Long): List<PhotoAttachment> =
        readableDatabase.rawQuery("SELECT * FROM photos WHERE record_id=? ORDER BY id", arrayOf(recordId.toString())).use { c ->
            buildList {
                while (c.moveToNext()) add(
                    PhotoAttachment(
                        id = c.long("id"),
                        recordId = recordId,
                        localPath = c.text("local_path"),
                        fileName = c.text("file_name"),
                        caption = c.text("caption"),
                        category = c.text("category"),
                    )
                )
            }
        }

    fun deleteRecord(id: Long) {
        record(id)?.photos?.forEach { File(it.localPath).delete() }
        writableDatabase.delete("activities", "id=?", arrayOf(id.toString()))
    }

    fun deletePhoto(id: Long) {
        readableDatabase.rawQuery("SELECT local_path FROM photos WHERE id=?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) File(it.getString(0)).delete()
        }
        writableDatabase.delete("photos", "id=?", arrayOf(id.toString()))
    }

    fun stats(): DashboardStats {
        val today = java.time.LocalDate.now()
        val monthStart = today.withDayOfMonth(1).toString()
        fun scalar(sql: String, args: Array<String> = emptyArray()) =
            readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return DashboardStats(
            total = scalar("SELECT COUNT(*) FROM activities"),
            today = scalar("SELECT COUNT(*) FROM activities WHERE date=?", arrayOf(today.toString())),
            month = scalar("SELECT COUNT(*) FROM activities WHERE date>=?", arrayOf(monthStart)),
            support = scalar("SELECT COUNT(*) FROM activities WHERE activity_category='Technical Support'"),
            project = scalar("SELECT COUNT(*) FROM activities WHERE activity_category='Project Delivery Support'"),
            training = scalar("SELECT COUNT(*) FROM activities WHERE activity_category='Training'"),
            solved = scalar("SELECT COUNT(*) FROM activities WHERE lower(status) IN ('solved','completed')"),
            pending = scalar("SELECT COUNT(*) FROM activities WHERE lower(status) IN ('pending','in progress','escalated')"),
            countries = scalar("SELECT COUNT(DISTINCT country) FROM activities WHERE country<>''"),
            products = scalar("SELECT COUNT(DISTINCT product) FROM activities WHERE product<>''"),
            totalMinutes = scalar("SELECT COALESCE(SUM(duration_minutes),0) FROM activities"),
        )
    }

    fun databaseFile(): File = appContext.getDatabasePath(DB_NAME)

    private fun ActivityRecord.toValues() = ContentValues().apply {
        put("date", date); put("project_name", projectName); put("purpose", purpose)
        put("remote_onsite", remoteOnsite); put("si_nd", siNd); put("contact_person", contactPerson)
        put("customer_name", customerName); put("country", country); put("description", description)
        put("enhanced_description", enhancedDescription); put("product", product); put("channel", channel)
        put("start_time", startTime); put("stop_time", stopTime); put("duration_minutes", durationMinutes)
        put("status", status); put("activity_category", activityCategory); put("fault_description", faultDescription)
        put("resolution", resolution); put("notes", notes); put("created_at", createdAt); put("updated_at", updatedAt)
    }

    private fun Cursor.toActivity() = ActivityRecord(
        id = long("id"), date = text("date"), projectName = text("project_name"), purpose = text("purpose"),
        remoteOnsite = text("remote_onsite"), siNd = text("si_nd"), contactPerson = text("contact_person"),
        customerName = text("customer_name"), country = text("country"), description = text("description"),
        enhancedDescription = text("enhanced_description"), product = text("product"), channel = text("channel"),
        startTime = text("start_time"), stopTime = text("stop_time"), durationMinutes = int("duration_minutes"),
        status = text("status"), activityCategory = text("activity_category"), faultDescription = text("fault_description"),
        resolution = text("resolution"), notes = text("notes"), createdAt = long("created_at"), updatedAt = long("updated_at"),
    )

    private fun Cursor.text(name: String) = getString(getColumnIndexOrThrow(name)) ?: ""
    private fun Cursor.int(name: String) = getInt(getColumnIndexOrThrow(name))
    private fun Cursor.long(name: String) = getLong(getColumnIndexOrThrow(name))

    companion object {
        private const val DB_NAME = "kpi_voice_journal.db"
        private const val DB_VERSION = 1
    }
}
