package com.rajkumar.kpijournal.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AppConfig(
    val products: List<String>,
    val countries: List<String>,
    val categories: List<String>,
    val modes: List<String>,
    val siNd: List<String>,
    val channels: List<String>,
    val statuses: List<String>,
    val photoCategories: List<String>,
)

class ConfigStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("journal_config", Context.MODE_PRIVATE)

    fun load(): AppConfig {
        val json = prefs.getString(KEY_CONFIG, null)
            ?: context.assets.open("default_config.json").bufferedReader().use { it.readText() }
        return JSONObject(json).toConfig()
    }

    fun save(config: AppConfig) {
        prefs.edit().putString(KEY_CONFIG, config.toJson().toString()).apply()
    }

    fun loadTemplateProfile(): String? = prefs.getString(KEY_TEMPLATE, null)
    fun saveTemplateProfile(json: String) = prefs.edit().putString(KEY_TEMPLATE, json).apply()
    fun clearTemplateProfile() = prefs.edit().remove(KEY_TEMPLATE).apply()

    private fun JSONObject.list(name: String) =
        optJSONArray(name)?.let { array -> List(array.length()) { array.optString(it) }.filter(String::isNotBlank) }.orEmpty()

    private fun JSONObject.toConfig() = AppConfig(
        products = list("products"),
        countries = list("countries"),
        categories = list("categories"),
        modes = list("modes"),
        siNd = list("siNd"),
        channels = list("channels"),
        statuses = list("statuses"),
        photoCategories = list("photoCategories"),
    )

    private fun AppConfig.toJson() = JSONObject().apply {
        put("products", JSONArray(products)); put("countries", JSONArray(countries)); put("categories", JSONArray(categories))
        put("modes", JSONArray(modes)); put("siNd", JSONArray(siNd)); put("channels", JSONArray(channels))
        put("statuses", JSONArray(statuses)); put("photoCategories", JSONArray(photoCategories))
    }

    companion object {
        private const val KEY_CONFIG = "app_config_json"
        private const val KEY_TEMPLATE = "excel_template_profile_json"
    }
}
