package com.rajkumar.kpijournal

import com.rajkumar.kpijournal.data.ActivityRecord
import com.rajkumar.kpijournal.data.JournalRecord
import com.rajkumar.kpijournal.excel.FieldMapper
import org.junit.Assert.assertEquals
import org.junit.Test

class FieldMapperTest {
    private val record = JournalRecord(ActivityRecord(projectName = "ABC", durationMinutes = 90, startTime = "10:00", stopTime = "11:30"))

    @Test fun mapsLegacyH1Headers() {
        assertEquals("ABC", FieldMapper.value(record, "Project Name"))
        assertEquals("10:00", FieldMapper.value(record, "startTime"))
        assertEquals("11:30", FieldMapper.value(record, "stopTime"))
        assertEquals("0 days 01:30", FieldMapper.value(record, "Averagae"))
    }

    @Test fun unknownHeaderIsBlank() {
        assertEquals("", FieldMapper.value(record, "Future Custom Column"))
    }
}
